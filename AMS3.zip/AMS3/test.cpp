#include<bits/stdc++.h>
using namespace std;

int main(){
    list<int>list1;
    int x;
    while(cin >> x){
        list1.push_back(x);
    }
    for(auto i:list1){
        if(i < 0)cout << -1 << " ";
        else if(i > 0)cout << 1 << " ";
        else cout << 0 << " ";
    }
}


